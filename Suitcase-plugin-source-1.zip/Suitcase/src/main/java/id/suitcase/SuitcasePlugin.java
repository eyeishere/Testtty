package id.suitcase;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class SuitcasePlugin extends JavaPlugin implements TabExecutor {

    private Game game;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        PluginCommand cmd = getCommand("suitcase");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        if (game != null) {
            game.cleanup();
        }
    }

    void clear(Game g) {
        if (game == g) {
            game = null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase();

        switch (sub) {
            case "start" -> {
                if (!(sender instanceof Player host)) {
                    sender.sendMessage("Command ini hanya untuk pemain.");
                    return true;
                }
                if (!host.hasPermission("suitcase.host")) {
                    host.sendMessage("§cKamu tidak punya izin.");
                    return true;
                }
                if (game != null) {
                    host.sendMessage("§cGame sedang berjalan. Pakai /suitcase stop dulu.");
                    return true;
                }
                List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
                int min = getConfig().getInt("min-players", 3);
                if (players.size() < min) {
                    host.sendMessage("§cButuh minimal " + min + " pemain online (termasuk host).");
                    return true;
                }
                game = new Game(this, host, players);
                game.begin();
            }
            case "stop" -> {
                if (!sender.hasPermission("suitcase.host")) {
                    sender.sendMessage("§cKamu tidak punya izin.");
                    return true;
                }
                if (game == null) {
                    sender.sendMessage("§cTidak ada game yang berjalan.");
                    return true;
                }
                game.cleanup();
                sender.sendMessage("§aGame dihentikan.");
            }
            case "rules" -> {
                if (sender instanceof Player p && game != null) {
                    game.showRules(p);
                }
            }
            case "vote" -> {
                if (sender instanceof Player p && game != null) {
                    game.reopenVote(p);
                }
            }
            case "tukar", "tetap" -> {
                if (sender instanceof Player p && game != null) {
                    game.decide(p, sub.equals("tukar"));
                }
            }
            default -> sender.sendMessage("§e/suitcase <start|stop|rules|vote|tukar|tetap>");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return List.of("start", "stop", "rules", "vote", "tukar", "tetap");
        }
        return List.of();
    }
}
